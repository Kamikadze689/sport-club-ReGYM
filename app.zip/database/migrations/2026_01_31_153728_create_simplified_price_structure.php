<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Создаем категории
        Schema::create('price_categories', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description')->nullable();
            $table->integer('order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // Создаем свойства категорий (ручные, создаются вручную)
        Schema::create('price_category_properties', function (Blueprint $table) {
            $table->id();
            $table->foreignId('category_id')->constrained('price_categories')->onDelete('cascade');
            $table->string('name'); // Название свойства (например: "Время посещения")
            $table->text('values')->nullable(); // Значения через запятую
            $table->integer('order')->default(0);
            $table->timestamps();
        });

        // Создаем объекты (тарифы)
        Schema::create('price_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('category_id')->constrained('price_categories')->onDelete('cascade');
            $table->string('name'); // Название тарифа (например: "Разовая тренировка")
            $table->json('property_values'); // Значения свойств в JSON
            $table->decimal('price', 10, 2);
            $table->text('description')->nullable();
            $table->boolean('has_discount')->default(false);
            $table->boolean('is_popular')->default(false);
            $table->integer('order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('price_items');
        Schema::dropIfExists('price_category_properties');
        Schema::dropIfExists('price_categories');
    }
};