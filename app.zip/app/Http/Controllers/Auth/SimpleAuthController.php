<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class SimpleAuthController extends Controller
{
    // Хардкодные учетные данные
    private $adminCredentials = [
        'email' => 'admin@gym.com',
        'password' => 'admin123', // Можете поменять
        'name' => 'Администратор'
    ];

    /**
     * Показать форму входа
     */
    public function showLoginForm()
    {
        return view('auth.simple_login');
    }

    /**
     * Обработать попытку входа
     */
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        // Проверяем хардкодные данные
        if ($request->email === $this->adminCredentials['email'] && 
            $request->password === $this->adminCredentials['password']) {
            
            // Создаем сессию
            session([
                'admin_logged_in' => true,
                'admin_name' => $this->adminCredentials['name'],
                'admin_email' => $this->adminCredentials['email']
            ]);
            
            return redirect()->intended('admin');
        }

        return back()->withErrors([
            'email' => 'Неверные учетные данные',
        ]);
    }

    /**
     * Выйти из системы
     */
    public function logout(Request $request)
    {
        session()->forget(['admin_logged_in', 'admin_name', 'admin_email']);
        return redirect('/');
    }
}