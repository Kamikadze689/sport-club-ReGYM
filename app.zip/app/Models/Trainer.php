<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Trainer extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'specializations', // только множественное число
        'description',
        'photo',
        'sports',
        'experience_years',
        'quote',
        'order',
        'is_active'
    ];

    protected $casts = [
        'specializations' => 'array', // каст в массив, как и sports
        'sports' => 'array',
        'is_active' => 'boolean'
    ];

    /**
     * Получить безопасный массив специализаций
     */
    public function getSpecializationsArrayAttribute()
    {
        if (is_array($this->specializations)) {
            return array_filter($this->specializations, function($item) {
                return !empty(trim($item));
            });
        }
        
        if (is_string($this->specializations) && !empty($this->specializations)) {
            $decoded = json_decode($this->specializations, true);
            if (is_array($decoded)) {
                return array_filter($decoded, function($item) {
                    return !empty(trim($item));
                });
            }
        }
        
        return [];
    }

    /**
     * Получить первую специализацию (для обратной совместимости в шаблонах)
     */
    public function getSpecializationAttribute()
    {
        $specializations = $this->getSpecializationsArrayAttribute();
        return !empty($specializations) ? $specializations[0] : null;
    }

    /**
     * Получить безопасный массив видов спорта
     */
    public function getSportsArrayAttribute()
    {
        if (is_array($this->sports)) {
            return array_filter($this->sports, function($item) {
                return !empty(trim($item));
            });
        }
        
        if (is_string($this->sports) && !empty($this->sports)) {
            $decoded = json_decode($this->sports, true);
            if (is_array($decoded)) {
                return array_filter($decoded, function($item) {
                    return !empty(trim($item));
                });
            }
        }
        
        return [];
    }

    /**
     * Проверить, есть ли у тренера специализации
     */
    public function hasSpecializations()
    {
        return !empty($this->getSpecializationsArrayAttribute());
    }

    /**
     * Проверить, есть ли у тренера виды спорта
     */
    public function hasSports()
    {
        return !empty($this->getSportsArrayAttribute());
    }

    /**
     * Получить специализации в виде строки
     */
    public function getSpecializationsStringAttribute()
    {
        $specializations = $this->getSpecializationsArrayAttribute();
        return !empty($specializations) ? implode(', ', $specializations) : '';
    }

    /**
     * Получить виды спорта в виде строки
     */
    public function getSportsStringAttribute()
    {
        $sports = $this->getSportsArrayAttribute();
        return !empty($sports) ? implode(', ', $sports) : '';
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('order')->orderBy('name');
    }
}