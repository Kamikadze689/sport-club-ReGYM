<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use App\Models\Trainer;

return new class extends Migration
{
    public function up(): void
    {
        // Проверяем, есть ли поле specialization
        if (Schema::hasColumn('trainers', 'specialization')) {
            // Проверяем, есть ли уже поле specializations
            if (!Schema::hasColumn('trainers', 'specializations')) {
                // Добавляем новое поле только если его нет
                Schema::table('trainers', function (Blueprint $table) {
                    $table->json('specializations')->nullable()->after('specialization');
                });
            }
            
            // Переносим данные из старого поля в новое
            $trainers = Trainer::all();
            foreach ($trainers as $trainer) {
                $oldValue = $trainer->getRawOriginal('specialization');
                if (!empty($oldValue) && empty($trainer->specializations)) {
                    $trainer->specializations = json_encode([$oldValue]);
                    $trainer->save();
                }
            }
            
            // Удаляем старое поле
            Schema::table('trainers', function (Blueprint $table) {
                $table->dropColumn('specialization');
            });
        } else {
            // Если поля specialization нет, проверяем наличие specializations
            if (!Schema::hasColumn('trainers', 'specializations')) {
                Schema::table('trainers', function (Blueprint $table) {
                    $table->json('specializations')->nullable()->after('name');
                });
            }
        }
    }

    public function down(): void
    {
        // Восстанавливаем старое поле, если его нет
        if (!Schema::hasColumn('trainers', 'specialization')) {
            Schema::table('trainers', function (Blueprint $table) {
                $table->string('specialization')->nullable()->after('name');
            });
        }
        
        // Переносим данные обратно
        $trainers = Trainer::all();
        foreach ($trainers as $trainer) {
            $specializations = json_decode($trainer->specializations, true);
            if (!empty($specializations) && is_array($specializations)) {
                $trainer->specialization = $specializations[0];
                $trainer->save();
            }
        }
        
        // Удаляем новое поле, если оно существует
        if (Schema::hasColumn('trainers', 'specializations')) {
            Schema::table('trainers', function (Blueprint $table) {
                $table->dropColumn('specializations');
            });
        }
    }
};