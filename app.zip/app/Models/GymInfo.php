<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GymInfo extends Model
{
    use HasFactory;

    protected $fillable = [
        'key',
        'value',
        'type',
        'description'
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
    
    /**
     * Получить значение по ключу
     */
    public static function getValue(string $key, $default = null)
    {
        $setting = self::where('key', $key)->first();
        return $setting ? $setting->value : $default;
    }
    
    /**
     * Установить значение
     */
    public static function setValue(string $key, $value, $type = 'text', $description = null)
    {
        return self::updateOrCreate(
            ['key' => $key],
            [
                'value' => $value,
                'type' => $type,
                'description' => $description
            ]
        );
    }
    
    /**
     * Получить все настройки в виде массива
     */
    public static function getAllAsArray()
    {
        return self::all()->pluck('value', 'key')->toArray();
    }
    
    /**
     * Получить все настройки как коллекцию
     */
    public static function getAll()
    {
        return self::all();
    }
}